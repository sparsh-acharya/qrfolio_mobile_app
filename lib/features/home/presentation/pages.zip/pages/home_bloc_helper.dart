import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:qr_folio/features/home/presentation/bloc/home_bloc.dart';

class HomeBlocHelper extends StatefulWidget {
  const HomeBlocHelper({super.key});

  @override
  State<HomeBlocHelper> createState() => _HomeBlocHelperState();
}

class _HomeBlocHelperState extends State<HomeBlocHelper> {
  @override
  void initState() {
    super.initState();
    context.read<HomeBloc>().add(GetUserDataEvent());
  }
  @override
  Widget build(BuildContext context) {
    return BlocConsumer<HomeBloc, HomeState>(
      listener: (context, state) {
        if(state is HomeErrorState){
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(state.message)),
          );
        }else if(state is HomeLoadedState){
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("User Data Loaded Successfully")),
          );
        }
      },
      builder: (context, state) {
        if(state is HomeLoadingState){
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        } else if(state is HomeErrorState){
          return Scaffold(
            body: Center(child: Text(state.message)),
          );
        } else if(state is HomeLoadedState){
          return Scaffold(
            body: Center(child: Text("Welcome, ${state.user.core.phone}!")),
          );
        } else {
          return const SizedBox();
        }
      },
    );
  }
}
