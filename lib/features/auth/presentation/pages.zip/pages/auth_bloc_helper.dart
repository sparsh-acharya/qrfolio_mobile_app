import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:qr_folio/features/auth/presentation/bloc/auth_bloc.dart';
import 'package:qr_folio/features/auth/presentation/pages/authpage.dart';
import 'package:qr_folio/features/home/presentation/pages/home.dart';
import 'package:qr_folio/features/home/presentation/pages/home_bloc_helper.dart';

class AuthBlocHelper extends StatefulWidget {
  const AuthBlocHelper({super.key});

  @override
  State<AuthBlocHelper> createState() => _AuthBlocHelperState();
}

class _AuthBlocHelperState extends State<AuthBlocHelper> {
  @override
  Widget build(BuildContext context) {
    return BlocConsumer<AuthBloc, AuthState>(
      listener: (context, state) {
        if(state is AuthenticatedState){
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Login Successful")),
          );
        }
      },
      builder: (context, state) {
        if(state is AuthInitialState || state is UnauthenticatedState){
          return const Authpage();
        } else if(state is AuthLoadingState){
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        } else if(state is AuthFailureState){
          return Scaffold(
            body: Center(child: Text(state.message)),
          );
        } else if(state is AuthenticatedState){
          return const HomeBlocHelper();
        } else {
          return const SizedBox();
        }
      },
    );
  }
}
